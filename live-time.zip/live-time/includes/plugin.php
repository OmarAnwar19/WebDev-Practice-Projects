<?php

//Adding our actual live time function
function add_live_time() {
    $js_url = PLUGIN_DIR_URL . "frontend/assets/js/live-time.js";
    echo '<div class="live-time"><script src="'.$js_url.'"></script></div>';
}

add_action( "twentysixteen_credits", "add_live_time", 10); 
