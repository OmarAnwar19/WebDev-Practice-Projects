<?php

function plugin_settings_menus() {
    add_submenu_page(
        "tools.php",                                    //The name of the parent page slug
        __("Live-Time Settings", "live-time"),          //The plugin sub-Menu Name (not in sidebar)
        __("Live-Time Settings", "live-time"),           //The menu name we want to appear in the sidebar
        "manage_options",                               //User Permissions (what they can do)
        "live-time",                                    //URL Slug
        "submenu_cb",                                   //Menu Callback Function
        100                                             //Priority (Where it is in the menu bar)
    );                                                  
}

add_action( "admin_menu", "plugin_settings_menus" );

function submenu_cb() {
    ?>
    <h1>Want to get in touch? Send us an Email!</h1>
    <form action="mailto:hicat22556@songsign.com" method="POST" enctype="multipart/form-data" name="EmailForm">

    <label for="ContactName">Name:</label><br>
    <input type="text" size="19" name="ContactName"><br><br>

    <label for="ContactCommentt">Message:</label><br><br> 
    <textarea name="ContactCommentt" rows="6" cols="20"></textarea><br><br> 
    
    <button type="submit" value="Submit">Send</button>

    </form>
<?php
}