<?php 

//Load JS files for front-end pages (the actual website)
function wp_plugin_frontend_scripts() {

    wp_register_script( "live-time-main", PLUGIN_DIR_URL . "frontend/assets/js/live-time.js", [], 1.0 );

    if (is_single()) wp_enqueue_script( "live-time-main" );

}

add_action( "wp_enqueue_scripts", "wp_plugin_frontend_scripts" );