<?php 

//Adding our settings link
function add_settings_link( $links ) {
    $settings_link = '<a href="tools.php?page=live-time">'.__("Settings", 'live-time')."</a>";
    array_push($links, $settings_link);
    return $links;
}

$plugin_filter = "plugin_action_links_".plugin_basename(__FILE__);
add_filter( $plugin_filter , "add_settings_link" );
