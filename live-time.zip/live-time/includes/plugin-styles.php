<?php 

//Load CSS files for admin pages (the admin dashboard)
function wp_plugin_admin_styles( $hook ) {

    wp_enqueue_style( "plugin-admin-styles", PLUGIN_DIR_URL . "admin/assets/css/plugin-admin-styles.css", [], 1.0 );

    //toplevel_page_PLUGIN-DOMAIN
    if ("toplevel_page_live-time" == $hook) wp_enqueue_style( "plugin-admin-styles" );

}

add_action( "admin_enqueue_scripts", "wp_plugin_admin_styles" );