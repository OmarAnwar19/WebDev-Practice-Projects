<?php

function plugin_settings() {

  // If plugin settings don't exist, then create them
  if( false == get_option( 'plugin_settings' ) ) {
      add_option( 'plugin_settings' );
  }

  // Define (at least) one section for our fields
  add_settings_section(
    // Unique identifier for the section
    'plugin_settings_section',
    // Section Title
    __( 'Plugin Settings Section', 'live-time' ),
    // Callback for an optional description
    'plugin_settings_section_callback',
    // Admin page to add section to
    'live-time'
  );

  // Input Text Field
  add_settings_field(
    // Unique identifier for field
    'plugin_settings_input_text',
    // Field Title
    __( 'Text Input', 'live-time'),
    // Callback for field markup
    'plugin_settings_text_input_callback',
    // Page to go on
    'live-time',
    // Section to go in
    'plugin_settings_section'
  );

  // Textarea Field
  add_settings_field(
    'plugin_settings_textarea',
    __( 'Text Area', 'live-time'),
    'plugin_settings_textarea_callback',
    'live-time',
    'plugin_settings_section'
  );

  // Checkbox Field
  add_settings_field(
    'plugin_settings_checkbox',
    __( 'Checkbox', 'live-time'),
    'plugin_settings_checkbox_callback',
    'live-time',
    'plugin_settings_section',
    [
      'label1' => 'Checkbox Label 1',
      'label2' => 'Checkbox Label 2',
    ]
  );

  // Radio Field
  add_settings_field(
    'plugin_settings_radio',
    __( 'Radio', 'live-time'),
    'plugin_settings_radio_callback',
    'live-time',
    'plugin_settings_section',
    [
      'option_one' => 'Radio 1',
      'option_two' => 'Radio 2'
    ]
  );

  // Dropdown
  add_settings_field(
    'plugin_settings_select',
    __( 'Select', 'live-time'),
    'plugin_settings_select_callback',
    'live-time',
    'plugin_settings_section',
    [
      'option_one' => 'Select Option 1',
      'option_two' => 'Select Option 2',
      'option_three' => 'Select Option 3'
    ]
  );


  register_setting(
    'plugin_settings',
    'plugin_settings'
  );

}
add_action( 'admin_init', 'plugin_settings' );

function plugin_settings_section_callback() {

  esc_html_e( 'Plugin settings section description', 'live-time' );

}

function plugin_settings_text_input_callback() {

  $options = get_option( 'plugin_settings' );

	$text_input = '';
	if( isset( $options[ 'text_input' ] ) ) {
		$text_input = esc_html( $options['text_input'] );
	}

  echo '<input type="text" id="plugin_customtext" name="plugin_settings[text_input]" value="' . $text_input . '" />';

}

function plugin_settings_textarea_callback() {

  $options = get_option( 'plugin_settings' );

	$textarea = '';
	if( isset( $options[ 'textarea' ] ) ) {
		$textarea = esc_html( $options['textarea'] );
	}

  echo '<textarea id="plugin_settings_textarea" name="plugin_settings[textarea]" rows="5" cols="50" style="resize:none" >' . $textarea . '</textarea>';

}

function plugin_settings_checkbox_callback( $args ) {

  $options = get_option( 'plugin_settings' );

  $checkbox = '';
	if( isset( $options[ 'checkbox' ] ) ) {
		$checkbox = esc_html( $options['checkbox'] );
	}

  //Checkbox Item 1
	$html = '<input type="checkbox" id="plugin_settings_checkbox_opt1" name="plugin_settings[checkbox_1]" value="1"' . checked( 1, $options['checkbox_1'], false ) . '/>'.'&nbsp;';
	$html .= '<label for="plugin_settings_checkbox_opt1">' . $args['label1'] . '</label>';

  //Line Break
  $html .= '<br>';

  //Checkbox Item 2
	$html .= '<input type="checkbox" id="plugin_settings_checkbox_opt2" name="plugin_settings[checkbox_2]" value="2"' . checked( 2, $options['checkbox_2'], false ) . '/>'.'&nbsp;';
	$html .= '<label for="plugin_settings_checkbox_opt2">' . $args['label2'] . '</label>';
	
  echo $html;

}

function plugin_settings_radio_callback( $args ) {

  $options = get_option( 'plugin_settings' );

  $radio = '';
	if( isset( $options[ 'radio' ] ) ) {
		$radio = esc_html( $options['radio'] );
	}

	$html = '<input type="radio" id="plugin_settings_radio_one" name="plugin_settings[radio]" value="1"' . checked( 1, $radio, false ) . '/>';
	$html .= ' <label for="plugin_settings_radio_one">'. $args['option_one'] .'</label> &nbsp;';
	$html .= '<input type="radio" id="plugin_settings_radio_two" name="plugin_settings[radio]" value="2"' . checked( 2, $radio, false ) . '/>';
	$html .= ' <label for="plugin_settings_radio_two">'. $args['option_two'] .'</label>';

	echo $html;

}

function plugin_settings_select_callback( $args ) {

  $options = get_option( 'plugin_settings' );

  $select = '';
	if( isset( $options[ 'select' ] ) ) {
		$select = esc_html( $options['select'] );
	}

  $html = '<select id="plugin_settings_options" name="plugin_settings[select]">';

	$html .= '<option value="option_one"' . selected( $select, 'option_one', false) . '>' . $args['option_one'] . '</option>';
	$html .= '<option value="option_two"' . selected( $select, 'option_two', false) . '>' . $args['option_two'] . '</option>';
	$html .= '<option value="option_three"' . selected( $select, 'option_three', false) . '>' . $args['option_three'] . '</option>';

	$html .= '</select>';

	echo $html;

}
