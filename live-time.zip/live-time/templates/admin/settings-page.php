<div class="wrap">

    <!-- First, lets output the page title -->
    <h1><?php esc_html_e( get_admin_page_title(  ), "live-time"); ?></h1>

    <!-- Creating our actual settings form -->
    <form action="options.php" method="POST">
        <!-- Loading our plugin settings field we declared before -->
        <?php settings_fields("plugin_settings"); ?>

        <!-- Display all of our loaded plugin settings sections -->
        <?php do_settings_sections( "live-time" ); ?>

        <!-- Creating our form submit button -->
        <?php submit_button(); ?>

    </form>

</div>