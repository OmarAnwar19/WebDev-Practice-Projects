<?php

//This is syntacticaly simillar to adding a menu, so, lets start with a function
function plugin_settings() {

    //First, check if we already have settings in our databse, if not, add them
    if (!get_option( "plugin_settings" )) {
        add_option( "plugin_settings" );
    }

    //inside this function, we add a settings section, which takes in 4 arguments
    //add_settings_section(
    //         "section_identifier", "section_title", "callback_function", "parent_page")
    add_settings_section(
        "settings_section1",                            //unique section identifier
        __("First Settings Section", "live-time"),      //section name
        "settings_section1_cb",                         //section callback function
        "live-time"                                     //parent page to add the section to
    );

    //Next, we have to actually add input fields into the section
    add_settings_field(
        "settings_field1",                              //unique field identifier
        __("Section Field Uno", "live-time"),           //field name
        "settings_field1_cb",                           //field callback function
        "live-time",                                    //parent page to add the field to
        "settings_section1"                             //settings section to add the field to
    );

    //Let's try to add a textbox
    add_settings_field(
        "settings_name",                                //unique field identifier
        __("Name", "live-time"),                        //field name
        "settings_name_cb",                             //field callback function
        "live-time",                                    //parent page to add the field to
        "settings_section1",                            //settings section to add the field to
    );

    add_settings_field(
        "settings_checkbox",                            //unique field identifier
        __("Checkbox", "live-time"),                    //field name
        "settings_checkbox_cb",                         //field callback function
        "live-time",                                    //parent page to add the field to
        "settings_section1",                            //settings section to add the field to
        [
            "label" => "Checkbox Label"                 //input label
        ]
    );

    //Finally, we have to register the section and field
    register_setting(
        //Save (TO_SETTINGS_FIELD), THE_SETTINGS_FIELD
        "plugin_settings",
        "plugin_settings"
    );

}

//Then, we have to create the callback function for our settings section
function settings_section1_cb() {
    esc_html_e("Plugin settings section description", "live-time");
}

//We also have to add the callback function for our section fields
function settings_field1_cb() {

    //First, declare a variable for our field (so we can populate it from db if needed)
    $field1_options = null;

    //First, retrieve the field options from the database
    $options = get_option("plugin_settings");

    //Next, check if our db options already have the field
    if (isset($options["field1_options"])) {
        //Retrieve the options, and store them in our variable above
        $field1_options = esc_html($options["field1_options"]);
    }

    //Otherwise, if they're not set, we create and output a new field
    //input type="..." id="custom_id" name=option_above["custom_value_name"] value=$options_val_above
    echo '<input type="text" id="settings_field1" name="plugin_settings["field1_options"]" value="'.$field1_options.'" />';

}

//Textarea callback function
function settings_name_cb() {

    //First, declare a variable for our field (so we can populate it from db if needed)
    $name = null;

    //First, retrieve the field options from the database
    $options = get_option("plugin_settings");

    //Next, check if our db options already have the field
    if (isset($options["name"])) {
        //Retrieve the options, and store them in our variable above
        $name = esc_html($options["name"]);
    }

    //Otherwise, if they're not set, we create and output a new field
    //input type="..." id="custom_id" name=option_above["custom_value_name"] value=$options_val_above
    echo '<textarea id="name_textarea" name="plugin_settings["name"]" value="'.$name.'" cols="30" rows="10" style="resize: none" /></textarea>';

}

//Checkbox callback function
function settings_checkbox_cb($args) {
    
    //First, declare a variable for our field (so we can populate it from db if needed)
    $checkbox = null;

    //First, retrieve the field options from the database
    $options = get_option("plugin_settings");

    //Next, check if our db options already have the field
    if (isset($options["checkbox"])) {
        //Retrieve the options, and store them in our variable above
        $checkbox = esc_html($options["checkbox"]);
    }

    //Otherwise, if they're not set, we create and output a new field
    $html = '<input type="checkbox" id="plugin_settings_checkbox" name="plugin_settings["checkbox"]" value="1"'.checked(1,$checkbox,false).'/>';
    $html .= '&nbsp;';
    $html.= '<label for="plugin_settings_checkbox">'.$args["label"]."</label>";

    echo $html;

}

//Finally, lets add our settings using a hook
add_action( "admin_init", "plugin_settings" );