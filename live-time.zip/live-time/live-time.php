<?php
/**
 * Plugin Name:       live-time
 * Plugin URI:        
 * Description:       Plugin that inserts a live time into your page
 * Version:           1.0.0
 * Contributers:      omaranwar
 * Author:            Omar Anwar
 * Author URI:        https://www.omaranwar.ga
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       live-time
 * Domain Path:       /languages
*/

//Check incorrect launch
if ( ! defined( 'WPINC' )) die;

//Define our plugin URL
define("PLUGIN_DIR_URL", plugin_dir_url(__FILE__));

//Import plugin menus
include (plugin_dir_path( __FILE__ ) . "/includes/plugin-menus.php");

//Import plugin styles
include (plugin_dir_path( __FILE__ ) . "/includes/plugin-styles.php");

//Import plugin scripts
include (plugin_dir_path( __FILE__ ) . "/includes/plugin-scripts.php");

//Import plugin functions
include (plugin_dir_path( __FILE__ ) . "/includes/plugin-functions.php");

//Importing actual plug-in function
include (plugin_dir_path( __FILE__ ) . "/includes/plugin.php");