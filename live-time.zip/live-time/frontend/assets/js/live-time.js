var timeDisplay = document.querySelector(".live-time");

function refreshTime() {
  var dateString = new Date().toLocaleString("en-US", {
    timeZone: "EST",
  });

  var formattedString = dateString.replace(", ", " - ");
  timeDisplay.innerHTML = formattedString;
}

setInterval(refreshTime, 1000);
