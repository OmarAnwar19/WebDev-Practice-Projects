<?php

class Plugin_Class {
  private static $instance;

  public static function getInstance() {
    if (self::$instance == NULL) {
      self::$instance = new self();
    }

    return self::$instance;
  }

  private function __construct() {
    // implement hooks here
    remove_action("welcome_panel", "wp_welcome_panel");
    add_action( "welcome_panel", array($this, "custom_welcome_message"), 1 );
  }

  //Our actual plugin code...
  function custom_welcome_message() {
    $options = get_option( 'cdash_settings' );

    if ( isset( $options[ 'cdash_msg_title' ] ) ) {
    $title = esc_html( $options['cdash_msg_title'] );
  } else {
        $title = "Go to settings to create a custom message!";
    }

    if ( isset( $options[ 'cdash_msg_body' ] ) ) {
    $body = esc_html( $options['cdash_msg_body'] );
  } else {
        $body = "Nothing here yet!";
    }

    ?>
    <div class="cdash-content">
      <h3><?php esc_html_e( $title, "wpplugin" ); ?></h3>
        <p><?php esc_html_e( $body, "wpplugin" ); ?></p>
    </div>
  <?php
  }
}

Plugin_Class::getInstance();

