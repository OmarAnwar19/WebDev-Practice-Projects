<?php
/**
 * Plugin Name:       CDash Welcome Message
 * Plugin URI:        
 * Description:       This plugin allows you to display any custom message in place of the default admin dashboard welcome message.
 * Version:           1.0.0
 * Contributers:      omaranwar
 * Author:            Omar Anwar
 * Author URI:        https://www.omaranwar.ga
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        
 * Text Domain:       wpplugin
 * Domain Path:       /languages
*/

//Check incorrect launch
if ( ! defined( 'WPINC' )) die;

//Define our plugin URL
define("PLUGIN_URL", plugin_dir_url(__FILE__));

//Define our plugin DIR path
define("PLUGIN_PATH", plugin_dir_path(__FILE__));

//Define our plugin basename
define("PLUGIN_BASE", plugin_basename(__FILE__));

//Import plugin menus
include (plugin_dir_path( __FILE__ ) . "/includes/plugin-menus.php");

//Import plugin styles
include (plugin_dir_path( __FILE__ ) . "/includes/plugin-styles.php");

//Import plugin functions
include (plugin_dir_path( __FILE__ ) . "/includes/plugin-functions.php");

//Importing plug-in in options file
include (plugin_dir_path( __FILE__ ) . "/includes/plugin-options.php");

//Importing our menu settings fields
include (plugin_dir_path( __FILE__ ) . "/includes/plugin-settings-fields.php");

//Importing actual plug-in function
include (plugin_dir_path( __FILE__ ) . "/classes/plugin-class-singleton.php");