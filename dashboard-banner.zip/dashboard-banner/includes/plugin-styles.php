<?php 

//Load CSS files for admin pages (the admin dashboard)
function wp_plugin_admin_styles( $hook ) {

    wp_enqueue_style( "plugin-admin-styles", PLUGIN_URL . "admin/assets/css/plugin-admin-styles.css", [], 1.0 );

    if ("toplevel_page_wpplugin" == $hook) wp_enqueue_style( "plugin-admin-styles" );

}

add_action( "admin_enqueue_scripts", "wp_plugin_admin_styles" );