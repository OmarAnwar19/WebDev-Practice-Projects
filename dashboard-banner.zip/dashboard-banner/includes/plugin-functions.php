<?php 

//Adding our settings link
function add_settings_link( $links ) {
    $settings_link = '<a href="options-general.php?page=cdash">' . __('Settings', 'wpplugin') . '</a>';
    array_push($links, $settings_link);
    return $links;
}

$plugin_filter = "plugin_action_links_".PLUGIN_BASE;
add_filter( $plugin_filter , "add_settings_link" );
