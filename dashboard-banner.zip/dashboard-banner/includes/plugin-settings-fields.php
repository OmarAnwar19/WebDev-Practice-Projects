<?php

function cdash_settings() {

  // If plugin settings don't exist, then create them
  if( false == get_option( 'cdash_settings' ) ) {
      add_option( 'cdash_settings' );
  }

  // Define (at least) one section for our fields
  add_settings_section(
    'cdash_settings_section',
    __( 'Customize the default admin dashboard welcome message.', 'wpplugin' ),
    'cdash_settings_section_callback',
    'wpplugin'
  );

  // Input Text Field
  add_settings_field(
    'cdash_settings_input_text',
    __( 'Title', 'wpplugin'),
    'cd_title_cb',
    'wpplugin',
    'cdash_settings_section'
  );

  // Textarea Field
  add_settings_field(
    'cd_message_cb',
    __( 'Custom Dashboard Message', 'wpplugin'),
    'cd_message_cb',
    'wpplugin',
    'cdash_settings_section'
  );

  register_setting(
    'cdash_settings',
    'cdash_settings'
  );

}

function cdash_settings_section_callback() {

  esc_html_e( 'Choose the title and body of the dashboard welcome message', 'wpplugin' );

}

function cd_title_cb() {

  $options = get_option( 'cdash_settings' );

	$cdash_msg_title = '';
	if( isset( $options[ 'cdash_msg_title' ] ) ) {
		$cdash_msg_title = esc_html( $options['cdash_msg_title'] );
	}

  echo '<input type="text" id="cdash_msg_title" name="cdash_settings[cdash_msg_title]" value="' . $cdash_msg_title . '" />';

}

function cd_message_cb() {

  $options = get_option( 'cdash_settings' );

	$cdash_msg_body = '';
	if( isset( $options[ 'cdash_msg_body' ] ) ) {
		$cdash_msg_body = esc_html( $options['cdash_msg_body'] );
	}

  echo '<textarea id="cdash_msg_body" name="cdash_settings[cdash_msg_body]" rows="10" cols="50" style="resize:none" >' . $cdash_msg_body . '</textarea>';

}

add_action( 'admin_init', 'cdash_settings' );

