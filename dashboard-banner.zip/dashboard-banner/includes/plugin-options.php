<?php

function plugin_options() {    

    if (!get_option( "plugin_installed" )) {
        add_option( "plugin_installed", true );
    }

    //The rest is the same as before
    if (!get_option( "users_data" )) {
        $users = [
            "1"=>["Name"=>"John Doe", "Age"=>42],
            "2"=>["Name"=>"Mary Jane", "Age"=>36],
            "3"=>["Name"=>"Kevin Patrick", "Age"=>22], 
        ];

        add_option( "users_data", $users );
    }

}

//Finally, we have to hook onto a high level hook, to store our options
add_action( "admin_init", "plugin_options");