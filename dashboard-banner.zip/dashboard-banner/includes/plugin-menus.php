<?php

function plugin_settings_menus() {
    add_submenu_page(
        "options-general.php",                          //The name of the parent page slug
        __("CDash Settings", "wpplugin"),               //The plugin sub-Menu Name (not in sidebar)
        __("CDash Settings", "wpplugin"),               //The menu name we want to appear in the sidebar
        "manage_options",                               //User Permissions (what they can do)
        "cdash",                                        //URL Slug
        "submenu_cb",                                   //Menu Callback Function
        100                                             //Priority (Where it is in the menu bar)
    );                                                  
}

add_action( "admin_menu", "plugin_settings_menus" );

function submenu_cb() {
    //In our new settings, we should first check if the user can even manage settings
    if (!current_user_can("manage_options")) return;

    //if so, fetch the template for the settings page
    include (PLUGIN_PATH . "templates/admin/settings-page.php");
}